<?php
require("config.php");
$remove = array("@", "#", "(", ")", "*", "/","'",'"',"\\");
require("test.php");
require("test1.php");
require("test2.php");
require("test3.php");

?>