<?php 

session_destroy(); 
redirect(getLink('admin/index.php'));
exit;

?>