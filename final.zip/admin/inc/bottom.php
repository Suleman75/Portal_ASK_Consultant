<div id="site_info">
	<p>
        <?php echo sprintf(COPYRIGHT_TEXT, date('Y')); ?>
	</p>
</div>