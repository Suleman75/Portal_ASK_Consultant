

<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Bootstrap 3.3.6 -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="css/theme.css">
<link rel="stylesheet" href="css/custom.css">
<link rel="stylesheet" href="css/skins.min.css">
<link rel="stylesheet" href="css/bootstrap-datepicker3.min.css">
<script src="js/jQuery/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<script src="js/app.min.js"></script>
<?php require_once("inc/validation.php");?>