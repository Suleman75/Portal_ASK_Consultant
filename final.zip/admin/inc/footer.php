<footer class="main-footer">
    <?php echo sprintf(COPYRIGHT_TEXT, date('Y')); ?>
</footer>